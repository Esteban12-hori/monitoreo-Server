#!/bin/bash
echo "Iniciando instalación rápida apuntando a 20.153.165.55..."
python3 install.py --server http://20.153.165.55 --auto
